import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class Race {
    public static void main(String[] args) {
        final int numOfRacers = 5;
        CountDownLatch startSignal = new CountDownLatch(1);
        CountDownLatch finishSignal = new CountDownLatch(numOfRacers);

        // Створюємо гравців і запускаємо їх
        Racer[] racers = new Racer[numOfRacers];
        for (int i = 0; i < numOfRacers; i++) {
            racers[i] = new Racer("Racer #" + (i + 1), startSignal, finishSignal);
            racers[i].start();
        }

        // Запускаємо гонку
        startSignal.countDown();

        try {
            // Чекаємо, поки всі гравці завершать гонку
            finishSignal.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Відображаємо перших трьох переможців
        System.out.println("Переможці:");
        for (int i = 0; i < 3; i++) {
            System.out.println(racers[i].getName());
        }

        // Достроково завершуємо решту потоків
        for (int i = 3; i < numOfRacers; i++) {
            racers[i].interrupt();
        }
    }

    static class Racer extends Thread {
        private CountDownLatch startSignal;
        private CountDownLatch finishSignal;

        public Racer(String name, CountDownLatch startSignal, CountDownLatch finishSignal) {
            super(name);
            this.startSignal = startSignal;
            this.finishSignal = finishSignal;
        }

        public void run() {
            Random random = new Random();
            try {
                startSignal.await(); // Чекаємо на старт сигнал
                Thread.sleep(random.nextInt(5000)); // "Гонка"
            } catch (InterruptedException e) {
                // Перехоплення виключення, якщо потік був прерваний (дострокове завершення)
                System.out.println(getName() + " досрочно завершив гонку.");
            } finally {
                finishSignal.countDown(); // Сигналізуємо про завершення гонки
            }
        }
    }
}
